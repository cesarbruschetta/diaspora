//= require mailchimp/jquery.form
//= require mailchimp/jquery.validate
//= require mailchimp/jquery126.min