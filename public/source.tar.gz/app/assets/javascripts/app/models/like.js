app.models.Like = Backbone.Model.extend({ });
