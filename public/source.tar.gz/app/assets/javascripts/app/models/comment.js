app.models.Comment = Backbone.Model.extend({
  urlRoot: "/comments"
});
