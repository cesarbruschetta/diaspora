app.models.Block = Backbone.Model.extend({
  urlRoot : "/blocks"
});
