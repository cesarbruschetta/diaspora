app.views.PostViewerNav = app.views.Base.extend({
  templateName: "post-viewer/nav"
});