//=require "./feedback_view"
app.views.FeedbackActions = app.views.Feedback.extend({
  id : "user-controls",
  templateName : "feedback-actions"
});