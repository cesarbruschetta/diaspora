
ActsAsTaggableOn.force_lowercase = true

