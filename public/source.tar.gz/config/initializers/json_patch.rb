class Fixnum
  def to_json(options = nil)
    to_s
  end
end

