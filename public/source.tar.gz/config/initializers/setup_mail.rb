# if you wish to intercept emails to go to a particuar email address
#ActionMailer::Base.register_interceptor(DevelopmentMailInterceptor) if Rails.env.development?  
