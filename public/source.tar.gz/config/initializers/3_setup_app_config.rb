AppConfig.setup!
