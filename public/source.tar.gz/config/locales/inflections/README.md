This directory contains the definitions for the [i18n-inflector gem](https://github.com/siefca/i18n-inflector).
Also, look up for our wiki on [How to contribute translations](https://github.com/diaspora/diaspora/wiki/How-to-contribute-translations) for more information.
