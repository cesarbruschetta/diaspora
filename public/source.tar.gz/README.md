XXXXXXXXXXXXX

==============================================


Integração com as redes sociais


Sistema desenvolvido para Trabalho de Conclusão de Curso (TCC) do curso de "Sistema para Internet" da "Faculdade Municipal de São Caetano do Sul - USCS, São Paulo - Brasil"

********************
Integrantes do grupo

CESAR AUGUSTO BRUSCHETTA
FELIPE BONIFACIO FEITOSA
MARIANA BOGDAN BLASQUE
RODRIGO TOYOKAZU SHIMABUKURO


*************************
Aplicação desenvolvida em Ruby,JQuery, Ruby on Rails, Blueprint-CSS, baseada no "Diaspora" **[repositorio principal](https://github.com/diaspora/diaspora)**, **[project site](http://diasporaproject.org)**


********************
Diaspora is written by:
  Daniel Grippi
  Ilya Zhitomirskiy
  Maxwell Salzberg
  Raphael Sofaer





## Instalação:

seguir as instruções do projeto original

https://github.com/diaspora/diaspora/wiki/Installation-Guides


